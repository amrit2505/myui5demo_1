sap.ui.define(
    [],
    function(){
        return {
            getStatus : function(availability){
                if (availability === "available"){
                    return "Success";
                }
                else if (availability === "Out of Stock"){
                    return "Warning";
                }
                else if (availability === "Discontinued"){
                    return "Error";
                }
            }
        }
    }
);