sap.ui.define(
    ["tom/controller/BaseController",
        "sap/m/MessageBox",
        "sap/m/MessageToast",
        "tom/util/formatter",
	"sap/ui/layout/form/SimpleForm"
    ],
    function (BaseController, MessageBox, MessageToast, formatter) {
        return BaseController.extend("tom.controller.View1",
            {
                formatter_divya: formatter,
                OnInit: function () {
                    // this.oRouter = this.getOwnerComponent().getRouter();
                    var oRouter = this.getOwnerComponent().getRouter();
                },
                onSearch: function (oEvent) {
                    //Step 1 :- We need to know what user is entering in the search field
                    var searchValue = oEvent.getParameter("query");
                    if (searchValue.indexOf("-") !== -1) {
                        //Step 1 :- get the object of odata model
                        var oDataModel = this.getOwnerComponent().getModel();
                        //Step 2 :- Perform the read
                        var  sPath = "/ProductSet('" + searchValue + "')";
                        var that = this;
                        oDataModel.read(sPath, {
                            success: function(data){
                                that.getView().getModel("local").setProperty("/singleProductData", data);
                                that.oDefaultDialog = new sap.m.Dialog({
                                    title: "Available Products",
                                    content: new sap.ui.layout.form.SimpleForm({
                                        content: [
                                            new sap.m.Label({text: 'Name'}),
                                            new sap.m.Text({text : '{Name}'}),
                                            new sap.m.Label({text: 'Description'}),
                                            new sap.m.Text({text : '{Description}'}),
                                            new sap.m.Label({text: 'Category'}),
                                            new sap.m.Text({text : '{Category}'}),
                                            new sap.m.Label({text: 'Price'}),
                                            new sap.m.Text({text : '{Price} {Currency_Code}'})
                                        ]
                                    }),
                                    endButton: new sap.m.Button({
                                        text: "Close",
                                        press: function () {
                                            that.oDefaultDialog.close();
                                        }.bind(that)
                                    })
                                });
                                that.oDefaultDialog.setModel(that.getOwnerComponent().getModel("local"));
                                that.oDefaultDialog.getContent()[0].bindElement("/singleProductData");
                                that.oDefaultDialog.open();
                            },
                            error: function(oErr){
                                var sMsg = JSON.parse(oErr.responseText).error.innererror.errordetails[0].message;
                                MessageBox.error(sMsg);
                            }
                        })
                        //Step 3 :- display the data in popup
                        //Step 4 :- Error we will handler it
                    }
                    else {
                        //Step 2 :- Prepare a filter for that search
                        var oFilter1 = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, searchValue);
                        var oFilter2 = new sap.ui.model.Filter("type", sap.ui.model.FilterOperator.Contains, searchValue);
                        var oFilter = new sap.ui.model.Filter({
                            filters: [oFilter1, oFilter2],
                            and: false
                        });
                        //Step 3 :- Inject the filter inside the List control object
                        var oList = this.getView().byId("idList");
                        oList.getBinding("items").filter([oFilter]);
                    }
                },
                onOrder: function () {
                    // alert("Order is success");
                    MessageBox.confirm("Do you like to confirm order ?",
                        {
                            title: "Confirm Order !",
                            onClose: function (value) {
                                // console.log(value);
                                if (value === "OK") {
                                    MessageToast.show("Order was placed successfully, Order number is 98765E");
                                }
                                else {
                                    MessageBox.error("Order was rejected");

                                }
                            }
                        }
                    )
                },
                onNext: function (oParameter) {
                    var oRoute = this.getOwnerComponent().getRouter();
                    oRoute.navTo("detail", {
                        var_parameter: oParameter
                    });
                },
                onAdd: function(){
                    var oRoute = this.getOwnerComponent().getRouter();
                    oRoute.navTo("add");
                },
                onDelete: function (oEvent) {
                    //Step 1 :- Get the index of item which was clicked to be deleted
                    var oDeletedItem = oEvent.getParameter("listItem");
                    var sPath = oDeletedItem.getBindingContextPath();
                    var sIndex = sPath.split("/")[sPath.split("/").length - 1];
                    //Step 2 :- Read all the model data
                    var oModel = this.getOwnerComponent().getModel("local");
                    var aData = oModel.getProperty("/fruits");
                    //Step 3 :- Delete the item @ index
                    aData.splice(sIndex, 1);
                    //Step 4 :- Set the data back to model
                    oModel.setProperty("/fruits", aData);
                },
                onShowSelItems: function (params) {
                    //Step 1 :- Get the List control object
                    var oList = this.getView().byId("idList");
                    //Step 2 :- Get all our selected items
                    var arrayItems = oList.getSelectedItems();
                    //Step 3 :- Loop over the items and print them one by one
                    arrayItems.forEach(element => {
                        console.log(element.getTitle());
                    });
                },
                onItemPress: function (oEvent) {
                    //Step 1 :- Get the item object on which item was clicked
                    var oSelectedItem = oEvent.getParameter("listItem");
                    //Step 2 :- Get the value of the fruit name from that object
                    // var oFruitName = oSelectedItem.getTitle();
                    var oFruitLocation = oSelectedItem.getBindingContextPath();
                    //Step 3 :- Call router to navigate and set the value
                    var sIndex = oFruitLocation.split("/")[oFruitLocation.split("/").length - 1];
                    this.onNext(sIndex);
                },
            }
        );
    }
);