sap.ui.define(
    ["tom/controller/BaseController"],
    function(BaseController){
        return BaseController.extend("tom.controller.Empty",{
            onInit : function(){
                
            }
        })
    }
);