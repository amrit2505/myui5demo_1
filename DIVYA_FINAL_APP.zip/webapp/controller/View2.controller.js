sap.ui.define(
    ["tom/controller/BaseController",
     "sap/ui/model/Filter",
     "sap/ui/model/FilterOperator",
     "sap/m/MessageBox",
     "sap/m/MessageToast"
    ],
    function (BaseController, Filter, FilterOperator, MessageBox, MessageToast) {
        return BaseController.extend("tom.controller.View2",
            {
                onInit: function () {
                    var oRouter = this.getOwnerComponent().getRouter();
                    var oRoute = oRouter.getRoute("detail");
                    oRoute.attachMatched(this.herculis, this);
                },
                herculis: function (oEvent) {
                    // console.log("Welcome to the Routing Game !");
                    var myObj = oEvent.getParameter("arguments").var_parameter;
                    console.log("The value of the parameter is ", myObj);


                    //get the address of the selected fruit
                    var oFruitRelativePath = "/" + myObj;
                    //bind the View2 with this adress
                    this.getView().bindElement(oFruitRelativePath);
                },
                onSave: function(){
                    var obj = this;
                    MessageBox.confirm("Do you want to save ?",{
                        onClose: function(status){
                            obj.onClose(status);
                        }
                    });
                },
                onClose: function(status){
                    if(status === "OK"){
                        MessageToast.show("Your order is saved!");
                    }
                },
                onBack: function () {
                    // //Step 1 :- Get the object of parent ( App Component Controller)
                    // var oAppCon = this.getView().getParent();
                    // //Step 2 :- Navigate to the view 1
                    // oAppCon.to("idView1");

                    var oRouter = this.getOwnerComponent().getRouter();
                    oRouter.navTo("home");

                },
                myField: null,
                oPopupCities: null,
                oPopupSuppliers: null,
                onSearch: function(oEvent){
                    var sId = oEvent.getSource().getId();
                    if (sId.indexOf("supplierPopup") != -1) {
                        var oFilter = new Filter("name", FilterOperator.Contains, oEvent.getParameter("value"));
                        this.oPopupSuppliers.getBinding("items").filter([oFilter]);
                    }else{
                        var oFilter = new Filter("cityname", FilterOperator.Contains, oEvent.getParameter("value"));
                        this.oPopupCities.getBinding("items").filter([oFilter]);
                    }
                },
                onCancel: function(){
                    this.getView().byId("idTable").getBinding("items").filter([]);
                },
                onFilter: function (oEvent) {
                    if (!this.oPopupSuppliers) {
                        this.oPopupSuppliers = new sap.ui.xmlfragment("supplierPopup", "tom.fragment.popup", this);
                        //Step 1 :- Fet the object of i18n class of our application
                        var oResource = this.getOwnerComponent().getModel("i18n");
                        //Step 2 :- Get the text value
                        var sTitle = oResource.getResourceBundle().getText("XTIT_SUPPLIER");
                        //Step 3 :- Assign the value
                        this.oPopupSuppliers.setTitle(sTitle);
                        this.oPopupSuppliers.setMultiSelect(true);
                        this.getView().addDependent(this.oPopupSuppliers);
                        this.oPopupSuppliers.bindAggregation("items", {
                            path: 'local>/suppliers',
                            template: new sap.m.ObjectListItem({
                                intro: "{local>city}",
                                title: "{local>name}",
                                number: "{local>sincewhen}",
                                numberUnit: "{local>contactPerson}",
                                icon: "sap-icon://supplier"
                            })
                        });
                    }
                    else{
                        this.oPopupSuppliers.getBinding("items").filter([]);
                    }
                    this.oPopupSuppliers.open();
                },
                onRequest: function (oEvent) {
                    //get the object of the input field on which our F4 button was pressed
                    this.myField = oEvent.getSource();
                    //Creating object of my popup fragment
                    if (!this.oPopupCities) {
                        this.oPopupCities = new sap.ui.xmlfragment("cityPopup", "tom.fragment.popup", this);
                        //Step 1 :- Fet the object of i18n class of our application
                        var oResource = this.getOwnerComponent().getModel("i18n");
                        //Step 2 :- Get the text value
                        var sTitle = oResource.getResourceBundle().getText("XTIT_CITY");
                        //Step 3 :- Assign the value
                        this.oPopupCities.setTitle(sTitle);
                        this.getView().addDependent(this.oPopupCities);
                        this.oPopupCities.bindAggregation("items", {
                            path: 'local>/cities',
                            template: new sap.m.StandardListItem({
                                description: "{local>famous}",
                                title: "{local>cityname}"
                            })
                        });
                    }
                    else{
                        this.oPopupCities.getBinding("items").filter([]);
                    }
                    this.oPopupCities.open();
                },
                onConfirm: function (oEvent) {
                    var sId = oEvent.getSource().getId();
                    if (sId.indexOf("supplierPopup") != -1) {
                        //Step 1 :- User can select multiple items, and get all of them
                        var aItems = oEvent.getParameter("selectedItems");
                        if(aItems.length === 0){
                            return;
                        }
                        var aFilter = [];
                        //Step 2 :- For each item we will build a filter object
                        for ( var i = 0; i < aItems.length; i++){
                            const element = aItems[i];
                            aFilter.push(new Filter("name", FilterOperator.EQ, element.getTitle()));
                        }
                        //Step 3 :- Build a main filter with OR
                        var oFilter = new Filter({
                            filters: aFilter,
                            and: false
                        });
                        //Step 4 :- Push this filter to the table of Supplier
                        this.getView().byId("idTable").getBinding("items").filter(oFilter);
                    }
                    else {
                        var oSelectedItem = oEvent.getParameter("selectedItem");
                        this.myField.setValue(oSelectedItem.getTitle());
                    }
                },
                onBeforeRendering: function () {
                    // this.getView().byId("idCheck").setVisible(false);
                },
                onAfterRendering: function () {
                    // $("#idView2--idCheck").hide(
                    //     function(){
                    //         $(this).fadeIn(5000);
                    //     }
                    //  );
                }
            }
        )
    }
);