sap.ui.define(
    ["tom/controller/BaseController"],
    function(BaseController){
        return BaseController.extend("tom.controller.App",
            {
                OnInit: function(){

                }
            }
        );
    }
);