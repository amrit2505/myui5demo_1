sap.ui.define(
    ["tom/controller/BaseController",
     "sap/m/MessageToast"   
    ],
    function(BaseController, MessageToast){
        return BaseController.extend("tom.controller.Add",
            {
                onInit: function(){
                    this._localModel = this.getOwnerComponent().getModel("local");
                },
                onSave: function(){
                    //Step 1 :- Get the odata object
                    var  oDataModel = this.getOwnerComponent().getModel();
                    //Step 2 :- prepare the payload
                    var payload =  this._localModel.getProperty("/newProduct");
                    //Step 3 :- Fire post call using create method
                    oDataModel.create("/ProductSet", payload, 
                        {
                            success: function(){
                               MessageToast.show("The product has been created in SAP!!!");
                            },
                            error: function(){
                                MessageToast.show("Product cannot be created!!");
                            }
                        }
                    );
                    //Step 4 :- Handle the response
                },
                onDelete: function(){
                    var  ProductId = this._localModel.getProperty("/newProduct/ProductId");
                    var oDataModel = this.getOwnerComponent().getModel();

                    oDataModel.remove("/ProductSet('" + ProductId + "')", {
                        success: function(){
                            MessageToast.show("The product has been deleted");
                        },
                        error: function(){
                            MessageToast.show("The product cannot be deleted");
                        }
                    });
                }
            }
        )
    }
);